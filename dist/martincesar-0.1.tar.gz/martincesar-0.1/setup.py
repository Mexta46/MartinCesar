from setuptools import setup

setup(
    name="MartinCesar",
    version='0.1',
    packages=['martincesar'],
    description="",
    long_description=open('Readme.md',encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    author='martin',
)