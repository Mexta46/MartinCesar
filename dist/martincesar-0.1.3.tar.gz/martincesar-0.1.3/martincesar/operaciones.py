def sumanumeros(n1,n2):
    sumaT=n1+n2
    return sumaT